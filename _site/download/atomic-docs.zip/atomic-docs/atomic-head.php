<!-- Place any head info you would like shared between the styleguide and the root of your project. Eg. Links to js scripts etc.. -->

<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>

