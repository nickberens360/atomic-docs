<?php include ("head.php");?>
	<body class="modules">
	
	
	<div class="grid-row atoms-container">
			<?php include ("sidebar.php");?>
			
			
			<div class="atoms-main">
					<h1 id="modules" class="atomic-h1">modules</h1>
	
	
							<?php include ("categories/modules/modules.php");?>
              
	
	
			</div>
	</div>
	<div class="ad_js-actionDrawer ad_actionDrawer">
	<div class="ad_actionDrawer__wrap">
	    <div class="ad_js-actionClose  ad_actionDrawer__close"><i class="fa fa-times fa-3x"></i></div>
	    <div id="js_actionDrawer__content" class="actionDrawer__content"></div>
	<div/>
  </div>
	<?php include ("footer.php");?>