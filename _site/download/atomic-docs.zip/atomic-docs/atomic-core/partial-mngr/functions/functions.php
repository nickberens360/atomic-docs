<?php
	
	//require '/Applications/XAMPP/xamppfiles/htdocs/atomic-docs/config.php';

  require_once '../../config.php';
  
	require 'cat-delete-functions.php';
	require 'cat-create-functions.php';
	require 'file-create-functions.php';
	require 'file-delete-functions.php';
	require 'file-rename-functions.php';
	require 'file-move-functions.php';
	require 'notes-rename-functions.php';
	require 'validation.php';

?>